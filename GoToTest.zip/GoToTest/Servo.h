#ifndef SERVO_H
#define SERVO_H

#define SERVO_PIN 2

void setup_Servo();
void loop_Servo();

#endif