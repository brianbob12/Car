#ifndef WALLFOLLOWING_H
#define WALLFOLLOWING_H


void enable_WallFollowing();
void disable_WallFollowing();

void loop_WallFollowing();

#endif